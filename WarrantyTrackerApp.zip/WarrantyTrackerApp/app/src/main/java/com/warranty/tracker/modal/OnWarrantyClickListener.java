package com.warranty.tracker.modal;

public interface OnWarrantyClickListener {

    public void onWarrantClick(WarrantyItem warrantyItem);
}
