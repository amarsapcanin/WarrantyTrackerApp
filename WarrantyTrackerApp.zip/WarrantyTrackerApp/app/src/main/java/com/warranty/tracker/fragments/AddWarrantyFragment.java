package com.warranty.tracker.fragments;

import static android.app.Activity.RESULT_OK;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.warranty.tracker.R;
import com.warranty.tracker.activities.HomePageActivity;
import com.warranty.tracker.sqlite.DBHandler;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class AddWarrantyFragment extends Fragment {

    private ImageView imvCalenderAddWarranty;
    private EditText edtDateAddWarranty, edtWarrantyName;
    private ImageButton imvUploadPicture;
    private Button btnAdd;
    private DBHandler dbHandler;
    Uri selectedImageUri;

    final Calendar myCalendar = Calendar.getInstance();

    int SELECT_PICTURE = 200;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_warranty, container, false);

        edtWarrantyName = view.findViewById(R.id.edtWarrantyName);
        edtDateAddWarranty = view.findViewById(R.id.edtDateAddWarranty);
        imvCalenderAddWarranty = view.findViewById(R.id.imvCalenderAddWarranty);
        imvUploadPicture = view.findViewById(R.id.imvUploadPicture);
        btnAdd = view.findViewById(R.id.btnAdd);
        dbHandler = new DBHandler(getActivity());
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, day);
                updateLabel();
            }
        };
        edtDateAddWarranty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(getActivity(), date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        imvCalenderAddWarranty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(getActivity(), date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        imvUploadPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageChooser();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String warrantyName = edtWarrantyName.getText().toString();
                String warrantyDate = edtDateAddWarranty.getText().toString();

                if (warrantyName.isEmpty() && warrantyDate.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbHandler.addNewWarranty(warrantyName, warrantyDate, selectedImageUri.toString());
                Toast.makeText(getActivity(), "Warranty has been added.", Toast.LENGTH_SHORT).show();
                ((HomePageActivity)getActivity()).onBackPressed();
            }
        });

        return view;
    }

    private void updateLabel() {
        String myFormat = "dd/MM/yyyy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat);
        edtDateAddWarranty.setText(dateFormat.format(myCalendar.getTime()));
    }

    void imageChooser() {
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, SELECT_PICTURE);
        startActivityForResult(Intent.createChooser(i, "Select Picture"), SELECT_PICTURE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                imvUploadPicture.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imvUploadPicture.setImageURI(data.getData());
                selectedImageUri = data.getData();
                //selectedImageUri = getRealPathFromURI(data.getData());
            }
        }
    }
}